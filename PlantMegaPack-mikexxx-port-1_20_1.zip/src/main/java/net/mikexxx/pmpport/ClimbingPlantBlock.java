package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * Climbing vine plant (sweet peas, grape vine, kiwi, hop, ...). It is attached to the side of a solid block
 * (FACING = the side of the wall it clings to), can be climbed, and grows UP the wall: the top block ripens
 * through 4 stages (random ticks / bone meal) and when fully grown it adds a new block above itself,
 * up to MAX_HEIGHT blocks. Honeycomb stops the growth, an axe removes the wax.
 */
public class ClimbingPlantBlock extends Block implements BonemealableBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, 3);
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");
    public static final int MAX_HEIGHT = 6;

    private static final VoxelShape NORTH = Block.box(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 3.0D);
    private static final VoxelShape SOUTH = Block.box(0.0D, 0.0D, 13.0D, 16.0D, 16.0D, 16.0D);
    private static final VoxelShape WEST = Block.box(0.0D, 0.0D, 0.0D, 3.0D, 16.0D, 16.0D);
    private static final VoxelShape EAST = Block.box(13.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);

    public ClimbingPlantBlock(Properties props) {
        super(props);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(FACING, Direction.NORTH).setValue(STAGE, 0).setValue(WAXED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, STAGE, WAXED);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH;
            case WEST -> WEST;
            case EAST -> EAST;
            default -> NORTH;
        };
    }

    // ---------------------------------------------------------------- attaching

    private static boolean wallHolds(LevelReader level, BlockPos pos, Direction wallSide) {
        BlockPos wall = pos.relative(wallSide);
        return level.getBlockState(wall).isFaceSturdy(level, wall, wallSide.getOpposite());
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return wallHolds(level, pos, state.getValue(FACING));
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Direction clicked = ctx.getClickedFace();
        if (clicked.getAxis().isHorizontal()) {
            BlockState s = this.defaultBlockState().setValue(FACING, clicked.getOpposite());
            if (s.canSurvive(ctx.getLevel(), ctx.getClickedPos())) return s;
        }
        for (Direction d : ctx.getNearestLookingDirections()) {
            if (!d.getAxis().isHorizontal()) continue;
            BlockState s = this.defaultBlockState().setValue(FACING, d);
            if (s.canSurvive(ctx.getLevel(), ctx.getClickedPos())) return s;
        }
        return null;
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        return state.canSurvive(level, pos) ? state : Blocks.AIR.defaultBlockState();
    }

    // ---------------------------------------------------------------- growth (upwards along the wall)

    private BlockPos topOf(LevelReader level, BlockPos pos) {
        BlockPos p = pos;
        while (level.getBlockState(p.above()).is(this)) p = p.above();
        return p;
    }

    private BlockPos bottomOf(LevelReader level, BlockPos pos) {
        BlockPos p = pos;
        while (level.getBlockState(p.below()).is(this)) p = p.below();
        return p;
    }

    private int height(LevelReader level, BlockPos top) {
        int h = 1;
        BlockPos p = top.below();
        while (level.getBlockState(p).is(this)) { h++; p = p.below(); }
        return h;
    }

    private boolean canExtend(LevelReader level, BlockPos top, BlockState st) {
        BlockPos up = top.above();
        if (!level.getBlockState(up).isAir()) return false;
        if (!wallHolds(level, up, st.getValue(FACING))) return false;
        return height(level, top) < MAX_HEIGHT;
    }

    private boolean canGrow(LevelReader level, BlockPos pos) {
        BlockPos top = topOf(level, pos);
        BlockState st = level.getBlockState(top);
        return st.getValue(STAGE) < 3 || canExtend(level, top, st);
    }

    private void growStep(Level level, BlockPos pos) {
        BlockPos top = topOf(level, pos);
        BlockState st = level.getBlockState(top);
        if (st.getValue(WAXED)) return;
        if (st.getValue(STAGE) < 3) {
            level.setBlock(top, st.setValue(STAGE, st.getValue(STAGE) + 1), 2);
        } else if (canExtend(level, top, st)) {
            level.setBlock(top.above(), this.defaultBlockState().setValue(FACING, st.getValue(FACING))
                    .setValue(STAGE, 0).setValue(WAXED, false), 3);
        }
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(WAXED)) return;
        if (level.getBlockState(pos.above()).is(this)) return;             // only the top block grows
        if (level.getRawBrightness(pos, 0) >= 9 && random.nextInt(4) == 0) growStep(level, pos);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean isClient) {
        return !state.getValue(WAXED) && canGrow(level, pos);
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        growStep(level, pos);
    }

    // ---------------------------------------------------------------- waxing / axing

    private void setWax(Level level, BlockPos pos, boolean wax) {
        BlockPos p = bottomOf(level, pos);
        while (level.getBlockState(p).is(this)) {
            level.setBlock(p, level.getBlockState(p).setValue(WAXED, wax), 2);
            p = p.above();
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean waxed = state.getValue(WAXED);
        if (held.is(Items.HONEYCOMB) && !waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, true);
                level.levelEvent(null, 3003, pos, 0);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, false);
                level.levelEvent(null, 3004, pos, 0);
                held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
