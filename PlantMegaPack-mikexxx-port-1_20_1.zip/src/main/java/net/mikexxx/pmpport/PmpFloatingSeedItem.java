package net.mikexxx.pmpport;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.PlaceOnWaterBlockItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Edible item that plants a floating plant (water chestnut): right-click water = plant it,
 * otherwise (or when the water cannot hold it) the item is eaten. Uses its own item name.
 */
public class PmpFloatingSeedItem extends PlaceOnWaterBlockItem {
    final int color;
    final String latin;

    public PmpFloatingSeedItem(Block b, Properties p, int color, String latin) {
        super(b, p);
        this.color = color;
        this.latin = latin;
    }

    @Override
    public String getDescriptionId() {
        return this.getOrCreateDescriptionId();
    }

    @Override
    public Component getName(ItemStack stack) {
        return PmpItem.colored(Component.translatable(this.getDescriptionId()), color);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        PmpItem.tooltip(tip, latin, 0);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        InteractionResultHolder<ItemStack> placed = super.use(level, player, hand);
        ItemStack held = player.getItemInHand(hand);
        if (!placed.getResult().consumesAction() && this.isEdible() && player.canEat(this.getFoodProperties().canAlwaysEat())) {
            player.startUsingItem(hand);
            return InteractionResultHolder.consume(held);
        }
        return placed;
    }
}
