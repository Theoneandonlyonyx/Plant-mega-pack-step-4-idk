package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.CraftingMenu;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;

/** Potting table: works as a 3x3 crafting table (all planter / pot recipes are normal crafting recipes). */
public class PottingTableBlock extends HorizontalDirectionalBlock {
    public PottingTableBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(FACING, net.minecraft.core.Direction.SOUTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext c) {
        return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite());
    }

    @Override
    public InteractionResult use(BlockState s, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        player.openMenu(getMenuProvider(s, level, pos));
        return InteractionResult.CONSUME;
    }

    @Override
    public MenuProvider getMenuProvider(BlockState s, Level level, BlockPos pos) {
        return new SimpleMenuProvider((id, inv, p) -> new Menu(id, inv, ContainerLevelAccess.create(level, pos)),
                Component.translatable("block.pmp_mikexxx.potting_table"));
    }

    static class Menu extends CraftingMenu {
        private final ContainerLevelAccess acc;

        Menu(int id, net.minecraft.world.entity.player.Inventory inv, ContainerLevelAccess acc) {
            super(id, inv, acc);
            this.acc = acc;
        }

        @Override
        public boolean stillValid(Player p) {
            return acc.evaluate((l, pos) -> l.getBlockState(pos).getBlock() instanceof PottingTableBlock
                    && p.distanceToSqr(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) <= 64.0, true);
        }
    }
}
