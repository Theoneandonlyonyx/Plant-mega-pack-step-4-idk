package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Decorative block with a fixed custom shape (flower pots). */
public class ShapedBlock extends Block {
    private final VoxelShape shape;

    public ShapedBlock(Properties p, VoxelShape shape) {
        super(p);
        this.shape = shape;
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter l, BlockPos p, CollisionContext c) {
        return shape;
    }
}
