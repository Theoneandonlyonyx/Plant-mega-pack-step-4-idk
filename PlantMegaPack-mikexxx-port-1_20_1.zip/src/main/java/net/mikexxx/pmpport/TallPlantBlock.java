package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;

import javax.annotation.Nullable;

/**
 * One block / one item for 2- and 3-segment plants. SEGMENT = bottom/middle/top. Growth stages below tallFrom are a
 * single block, from tallFrom on the plant is `height` blocks tall (upper parts are placed when it grows).
 * Honeycomb waxes every segment, an axe removes the wax.
 */
public class TallPlantBlock extends PlantBlock implements SimpleWaterloggedBlock {
    public enum Segment implements StringRepresentable {
        BOTTOM("bottom"), MIDDLE("middle"), TOP("top");
        private final String n;
        Segment(String n) { this.n = n; }
        @Override public String getSerializedName() { return n; }
    }

    public static final EnumProperty<Segment> SEGMENT = EnumProperty.create("segment", Segment.class);
    public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;

    final int height;
    final int tallFrom;
    final boolean aqua;

    public TallPlantBlock(Properties props, int maxStage, int tallFrom, int height, boolean aqua) {
        super(props, maxStage, Type.GROUND);
        this.height = height;
        this.tallFrom = tallFrom;
        this.aqua = aqua;
        this.registerDefaultState(this.defaultBlockState().setValue(SEGMENT, Segment.BOTTOM).setValue(WATERLOGGED, aqua));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        super.createBlockStateDefinition(b);
        b.add(SEGMENT, WATERLOGGED);
    }

    private int heightAt(int stage) { return stage >= tallFrom ? height : 1; }

    private Segment seg(int i, int h) { return i == 0 ? Segment.BOTTOM : (i == h - 1 ? Segment.TOP : Segment.MIDDLE); }

    private BlockPos bottomPos(LevelReader l, BlockPos p, BlockState s) {
        while (s.is(this) && s.getValue(SEGMENT) != Segment.BOTTOM) {
            p = p.below();
            s = l.getBlockState(p);
        }
        return p;
    }

    private boolean hasSpace(LevelReader level, BlockPos bp, int from, int to) {
        for (int i = from; i < to; i++) {
            BlockState a = level.getBlockState(bp.above(i));
            if (!a.isAir() && !a.canBeReplaced()) return false;
        }
        return true;
    }

    // ----- placement -----
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        if (aqua) {
            FluidState fs = level.getFluidState(pos);
            if (!(fs.is(FluidTags.WATER) && fs.getAmount() == 8)) return null;
        }
        if (!hasSpace(level, pos, 1, heightAt(0))) return null;
        return this.defaultBlockState().setValue(WATERLOGGED, aqua);
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        int h = heightAt(state.getValue(STAGE));
        for (int i = h - 1; i >= 1; i--) {
            BlockPos q = pos.above(i);
            boolean wl = aqua && level.getFluidState(q).is(FluidTags.WATER);
            level.setBlock(q, state.setValue(SEGMENT, seg(i, h)).setValue(WATERLOGGED, wl), 3);
        }
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        if (state.getValue(SEGMENT) != Segment.BOTTOM) return level.getBlockState(pos.below()).is(this);
        return super.canSurvive(state, level, pos);
    }

    @Override
    public BlockState updateShape(BlockState s, Direction d, BlockState n, LevelAccessor l, BlockPos p, BlockPos np) {
        if (s.getValue(WATERLOGGED)) l.scheduleTick(p, Fluids.WATER, Fluids.WATER.getTickDelay(l));
        Segment sg = s.getValue(SEGMENT);
        if (sg == Segment.BOTTOM) {
            if (d == Direction.UP && heightAt(s.getValue(STAGE)) > 1 && !n.is(this)) return Blocks.AIR.defaultBlockState();
            if (d == Direction.DOWN && !s.canSurvive(l, p)) return Blocks.AIR.defaultBlockState();
            return s;
        }
        if (d == Direction.DOWN && !n.is(this)) return Blocks.AIR.defaultBlockState();
        if (d == Direction.UP && sg == Segment.MIDDLE && !n.is(this)) return Blocks.AIR.defaultBlockState();
        return s;
    }

    @Override
    public FluidState getFluidState(BlockState s) {
        return s.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(s);
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && state.getValue(SEGMENT) != Segment.BOTTOM) {
            BlockPos bp = bottomPos(level, pos, state);
            if (level.getBlockState(bp).is(this)) level.destroyBlock(bp, !player.isCreative(), player);
        }
        super.playerWillDestroy(level, pos, state, player);
    }

    // ----- growth -----
    private boolean advance(Level level, BlockPos bp, BlockState bs) {
        int st = bs.getValue(STAGE);
        if (st >= maxStage || bs.getValue(WAXED)) return false;
        int ns = st + 1, oh = heightAt(st), nh = heightAt(ns);
        if (!hasSpace(level, bp, oh, nh)) return false;
        for (int i = nh - 1; i >= 0; i--) {
            BlockPos q = bp.above(i);
            boolean wl;
            if (i < oh) {
                BlockState ex = level.getBlockState(q);
                wl = ex.is(this) && ex.getValue(WATERLOGGED);
            } else wl = aqua && level.getFluidState(q).is(FluidTags.WATER);
            level.setBlock(q, bs.setValue(STAGE, ns).setValue(SEGMENT, seg(i, nh)).setValue(WATERLOGGED, wl), 3);
        }
        return true;
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(SEGMENT) != Segment.BOTTOM || state.getValue(WAXED)) return;
        if (random.nextInt(6) == 0 && level.getRawBrightness(pos, 0) >= 8) advance(level, pos, state);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean client) {
        BlockPos bp = bottomPos(level, pos, state);
        BlockState bs = level.getBlockState(bp);
        if (!bs.is(this)) return false;
        int st = bs.getValue(STAGE);
        if (st >= maxStage || bs.getValue(WAXED)) return false;
        return hasSpace(level, bp, heightAt(st), heightAt(st + 1));
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource r, BlockPos pos, BlockState state) {
        BlockPos bp = bottomPos(level, pos, state);
        BlockState bs = level.getBlockState(bp);
        if (bs.is(this)) advance(level, bp, bs);
    }

    // ----- wax (all segments) -----
    private void setWax(Level level, BlockPos bp, BlockState bs, boolean w) {
        int h = heightAt(bs.getValue(STAGE));
        for (int i = 0; i < h; i++) {
            BlockPos q = bp.above(i);
            BlockState c = level.getBlockState(q);
            if (c.is(this)) level.setBlock(q, c.setValue(WAXED, w), 3);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        BlockPos bp = bottomPos(level, pos, state);
        BlockState bs = level.getBlockState(bp);
        if (!bs.is(this)) return InteractionResult.PASS;
        boolean waxed = bs.getValue(WAXED);
        if (held.is(Items.HONEYCOMB) && !waxed) {
            if (!level.isClientSide) {
                setWax(level, bp, bs, true);
                level.levelEvent(null, 3003, pos, 0);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && waxed) {
            if (!level.isClientSide) {
                setWax(level, bp, bs, false);
                level.levelEvent(null, 3004, pos, 0);
                held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
